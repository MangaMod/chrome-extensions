// Function to retrieve the current manga title and chapter from the webpage
function getCurrentMangaInfo() {
  const titleElement = document.querySelector('.manga-info h1');
  const chapterElement = document.querySelector('.chapter-title');
  
  if (titleElement && chapterElement) {
    const title = titleElement.innerText.trim();
    const chapter = chapterElement.innerText.trim();
    
    return { title, chapter };
  }
  
  return null;
}

// Function to save the last read chapter to local storage
function saveLastReadChapter(mangaInfo) {
  if (mangaInfo) {
    chrome.storage.sync.set({ 'lastReadChapter': mangaInfo });
  }
}

// Main function
function main() {
  const mangaInfo = getCurrentMangaInfo();
  saveLastReadChapter(mangaInfo);
}

main();
